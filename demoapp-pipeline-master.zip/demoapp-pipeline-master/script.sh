echo "# demo-pipeline" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin git@github.com:dhgautam/demo-pipeline.git
git push -u origin master
