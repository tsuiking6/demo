#! /bin/bash
echo "Run build script for demo pipeline"
touch target/demoapp.jar
