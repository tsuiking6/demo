#! /bin/bash
echo "Run Linux Tests"
